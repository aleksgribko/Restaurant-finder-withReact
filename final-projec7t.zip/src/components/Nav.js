import React from 'react'

function Nav(props){
	return <div id='nav' style={{height:'10vh'}}><h1>Restaurants around you with reviews</h1><button id='findMeButton'>Find me</button></div>
}

export default Nav